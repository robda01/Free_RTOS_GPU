#include "esp_log.h"
#include "yalgaar_api.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "mqtt_common.h"
#include "cJSON.h"

#define TAG "yalgaar_api"

#define QOS0 0
#define MAX_CHANNELS 5

static unsigned char *sendBuf;
static unsigned char *readBuf;

static Network network;
static MQTTClient client;

static bool connect_flag = false;
static xTaskHandle yalgaar_task_handle=NULL;
void (*sub_msg_call)(char*,int,char*) = NULL;
static void (*connect_call)(char*);
static char *global_client_key=NULL;
static char *global_uuid=NULL;

void (*history_call)(char **,int) = NULL;
void (*user_list_call)(sll*)= NULL;
void (*channel_list_call)(sll*) = NULL;
void (*presence_call)(presence_t *) = NULL;

static bool global_hex_flag=0;
static int sub_channel_cnt=0;
static char* cli_id = NULL;

void regist_yalgaar_error_callback(void (*yalgaar_call)(char*),char **error_string);
void append_key(char* clientKey, char* uuid, char* client);
int mqtt_client_connect_ops(char* clientKey,char* uuid,char* cli_id,char* global_client_key,char* global_uuid);
void Init_network(Network* n);
int connect_network(Network* n, char* host);
void disconnect_network(Network* n);


extern uint8_t is_mqtt_connect;
static char *yalgaar_error_string[] = {"Connection Successful","ClientId is NULL", "Invalid ClientId","ClientKey is not Registered","Invalid UUID","ClienKey is not Active", "SSL is Disabled","MAX connections limit reached","Invalid Subscribe Channel","Invalid Subscribe Channel.ClientKey not matched","Multiple Subscription not Allowed","Invalid Subscribe Channel.Check the channel name","History Storage Disabled","Presence is Disabled","Entered history channel has not been subscribed","Publish Message is NULL","Invalid Publish Channel","Invalid Publish Channel.ClientKey not matched","Message count exceeds MAX limit","Message size exceeds MAX limit","Invalid Publish Channel.Check the channel name","Invalid Unsubscribe Channel","Invalid Unsubscribe Channel.ClientKey not matched","Invalid Unsubscribe Channel.Check the channel name","Domain is not Authorized","Subscribe is disable for this UUID","Publish is disable for this UUID"};

/*	parse presence messgae for uuid, action and channel	*/
static void presence_message(void *jdata)
{
	cJSON *obj = NULL;
	cJSON *json_msg1 = NULL;
	cJSON *json_msg2 = NULL;
	obj = cJSON_Parse((const char*)jdata);
	if (obj != NULL)
	{
		json_msg2 = cJSON_GetObjectItem(obj,"isPresence");
		if(json_msg2 != NULL)
		{
			if(json_msg2->valueint)
			{
				presence_t *data = (presence_t*)malloc(sizeof(presence_t));
				if(data == NULL)
				{
					if(obj != NULL)
						cJSON_Delete(obj);
					ESP_LOGE(TAG,"memory alloc fail for presence_t data");
					return;

				}
				memset(data,0,sizeof(presence_t));
				json_msg1 = cJSON_GetObjectItem(obj,"uuid");
				if(json_msg1 != NULL)
				{
					strcpy(data->uuid,json_msg1->valuestring);
				}
				else{
					free(data);
					if(obj != NULL)
					cJSON_Delete(obj);
					ESP_LOGE(TAG,"cJSON_GetObjectItem failed for \"uuid\"");
					return;
				}
				json_msg1 = cJSON_GetObjectItem(obj,"action");
				if(json_msg1 != NULL)
				{
					if(strcmp(json_msg1->valuestring,"bind")==0)
					{
						data->action = true;
					}
					else
					{
						data->action = false;
					}
				}
				else{
					free(data);
					if(obj != NULL)
					cJSON_Delete(obj);
					ESP_LOGE(TAG,"cJSON_GetObjectItem failed for \"action\"");
					return;
				}

				json_msg1 = cJSON_GetObjectItem(obj,"channel");
				if(json_msg1 != NULL)
				{
					strcpy(data->channel,json_msg1->valuestring);
				}
				else{
					free(data);
					if(obj != NULL)
					cJSON_Delete(obj);
					ESP_LOGE(TAG,"cJSON_GetObjectItem failed for \"channel\"");
					return;
				}
				if(presence_call != NULL)
					presence_call(data);
				free(data);
			}
		}
		else
		{
			ESP_LOGE(TAG,"cJSON_GetObjectItem failed for \"isPresence\"");
			if(obj != NULL)
				cJSON_Delete(obj);
			return;
		}
	}
	else{
		ESP_LOGE(TAG,"JSON Parse object not created");
		return;
	}
	if(obj != NULL)
		cJSON_Delete(obj);
}

/*	convert hex-string data to hex data	*/
static void char_to_hex(const char* offset, char* command,uint16_t cmd_len)
{
	for(int i=0;i<cmd_len;i++)
	{
		sscanf(offset,"%2hhx",( char*)&command[i]);
		offset+=2;
	}
}

/* 	Parse json message for history, channel list and user list.
	takes array object of name key, from that array object take each element of array.
	for history type message that array element will be again a json object, it will be parsed again.
	final vlaue string of array will be taken elementwise in to buffer if history or into sll structure if user or channel list.
*/
static void parse_message(void *jdata, char *key)
{
	cJSON *obj = NULL;
	cJSON *json_msg = NULL;
	cJSON *json_msg1 = NULL;
	cJSON *json_msg2 = NULL;
	obj = cJSON_Parse((const char*)jdata);
	if (obj != NULL)
	{
		json_msg2 = cJSON_GetObjectItem(obj,key);
		if(json_msg2 != NULL)
		{
			int ar_size = cJSON_GetArraySize(json_msg2);
			char *data[ar_size];
			for (int i=0;i<ar_size;i++)
			{
				data[i] = NULL;
				json_msg = cJSON_GetArrayItem (json_msg2,i);
				if(json_msg != NULL)
				{
					if(strcmp(key,"history")==0)
					{
						json_msg1 = cJSON_GetObjectItem(json_msg,"message");
						if(json_msg1 != NULL)
						{
							if(global_hex_flag)
							{
								data[i] = (char*)malloc(strlen(json_msg1->valuestring)/2);
								if(data[i] == NULL)
								{
									ESP_LOGE(TAG,"Memory alloc error for history data");
									if(obj != NULL)
										cJSON_Delete(obj);
									return;
								}
								char_to_hex(json_msg1->valuestring,data[i],strlen(json_msg1->valuestring)/2);
							}
							else
								data[i] = json_msg1->valuestring;
						}
						else
						{
							ESP_LOGE(TAG,"cJSON_GetObjectItem error for \"message\"");
							if(obj != NULL)
								cJSON_Delete(obj);
							return;
						}
					}
					else
					{
						data[i] = json_msg->valuestring;
					}
				}
				else{
					ESP_LOGE(TAG,"cJSON_GetArrayItem error for parse message");
					if(obj != NULL)
						cJSON_Delete(obj);
					return;
				}
			}
			if(strcmp(key,"history")!=0)
			{
				sll* data1 = (sll*)malloc(sizeof(sll));
				if(data1 == NULL)
				{
					ESP_LOGE(TAG,"memory alloc failed for sll for \"history\"");
					if(obj != NULL)
						cJSON_Delete(obj);
					return;
				}
				memset(data1,0,sizeof(sll));

				data1->list = data;
				json_msg2 = cJSON_GetObjectItem(obj,"range");
				json_msg = cJSON_GetArrayItem (json_msg2,0);
				data1->low_range = json_msg->valueint;
				json_msg = cJSON_GetArrayItem (json_msg2,1);
				data1->high_range = json_msg->valueint;
				if(strcmp(key,"channels")==0)
					channel_list_call(data1);
				else
					user_list_call(data1);
				free(data1);
			}
			else
			{
				history_call(data,ar_size);
				if(global_hex_flag)
				{
					for(int i=0;i<ar_size;i++)
					free(data[i]);
				}
			}
		}
	}
	if(obj != NULL)
		cJSON_Delete(obj);
}


/*	this callback will be called on data event	*/
static void messageHandler_func_yalgaar(MessageData *md)
{
	ESP_LOGD(TAG,"In messageHandler_func_yalgaar");
	if (md->message->payloadlen)
	{
		if(md->message->payload == NULL)
		{
			ESP_LOGE(TAG,"Received data is NULL error...");
			return;
		}

		char *data = (char*)malloc(md->message->payloadlen+1);
		if(data == NULL)
		{
			ESP_LOGE(TAG,"memory alloc fail for data in data_cb");
			return;
		}
		memset(data,0,md->message->payloadlen+1);
		memcpy(data, md->message->payload,md->message->payloadlen);
		ESP_LOGD(TAG,"data received : %s",data);

		char *point = strstr(data,"\"message\":");
		if(point != NULL)
		{
			char *buf ;
			buf = (char*)malloc(md->message->payloadlen+13);	/* 13 for appending	{"history":} */
			if(buf == NULL)
			{
				ESP_LOGE(TAG,"Memory alloc fail for buffer in data_cb");
				free(data);
				return;
			}

			memset(buf,0,md->message->payloadlen+13);
			buf[0] = '{';
			memcpy(&buf[1],"\"history\":",10);
			memcpy(&buf[11],data,md->message->payloadlen);
			buf[md->message->payloadlen+1+10]= '}';
			parse_message(buf , "history");
			free(buf);
			free(data);
			return;
		}

		point = strstr(data,"\"channels\":");
		if(point != NULL)
		{
			parse_message(data ,"channels");
			free(data);
			return;
		}

		point = strstr(data,"\"users\":");
		if(point != NULL)
		{
			parse_message(data ,"users");
			free(data);
			return;
		}
		point = strstr(data,"\"isPresence\":");
		if(point != NULL)
		{
			presence_message(data);
			free(data);
			return;
		}

		char *channel = (char*)malloc((md->topicName->lenstring.len)-(strlen(global_client_key)+1)+1);
		if(channel == NULL)
		{
			ESP_LOGE(TAG,"Memory Allocation fails for received data Channel Name");
			free(data);
			return;
		}
		memset(channel,0,(md->topicName->lenstring.len)-(strlen(global_client_key)+1)+1);
		memcpy(channel,&md->topicName->lenstring.data[strlen(global_client_key)+1],(md->topicName->lenstring.len)-(strlen(global_client_key)+1));

		ESP_LOGD(TAG,"Channel ====  %s, len : %d",channel,(md->topicName->lenstring.len)-(strlen(global_client_key)+1)+1);

		if((sub_msg_call != NULL))
		{
			if(global_hex_flag)
			{
				char *sdata = (char*)malloc((md->message->payloadlen)/2);
				if(sdata == NULL)
				{
					ESP_LOGE(TAG,"Memory not allocated for sdata in data_cb");
					free(data);
					free(channel);
					return;
				}
				memset(sdata,0,(md->message->payloadlen)/2);
				char_to_hex(data,sdata,(md->message->payloadlen)/2);
				(*sub_msg_call)(sdata,(md->message->payloadlen)/2,channel);
				free(sdata);
			}
			else
				(*sub_msg_call)(data,(md->message->payloadlen),channel);
		}
		free(data);
		free(channel);
	}
}

void mqtt_yalgaar_task(void *ignore)
{
	sendBuf = (unsigned char*)malloc(MQTT_BUFFER_SIZE);
	if(sendBuf == NULL)
	{
		ESP_LOGE(TAG,"sendBuf malloc failed");
		vTaskDelete(NULL);
	}
	readBuf = (unsigned char*)malloc(MQTT_BUFFER_SIZE);
	if(readBuf == NULL)
	{
		ESP_LOGE(TAG,"readBuf malloc failed");
		free(sendBuf);
		vTaskDelete(NULL);
	}

	while(1)
	{
		Init_network(&network);
			int ret = 0;
			MQTTString clientId = MQTTString_initializer;
			MQTTPacket_connectData data = MQTTPacket_connectData_initializer;

			ESP_LOGI(TAG,"connecting to MQTT server ... ");

			ESP_LOGD(TAG, "NetworkConnect  ...");

			ret = connect_network(&network,(char *)YALGAAR_SERVER);

			if(!ret)
			{
				ESP_LOGI(TAG,"connected to Yalgaar");

				ESP_LOGD(TAG, "MQTTClientInit  ...");
				MQTTClientInit(&client, &network,
					CLIENT_CONNECTION_TIMEOUT_ms,            // command_timeout_ms
					sendBuf,         //sendbuf,
					MQTT_BUFFER_SIZE, //sendbuf_size,
					readBuf,         //readbuf,
					MQTT_BUFFER_SIZE  //readbuf_size
				);

				client.defaultMessageHandler = messageHandler_func_yalgaar;
				clientId.cstring = cli_id;
				data.clientID          = clientId;
				data.willFlag          = 0;
				data.MQTTVersion       = 3;
				data.keepAliveInterval = 30;
				data.cleansession      = 1;

				ESP_LOGI(TAG,"clientID : %s\r\n",data.clientID.cstring );
				ret = MQTTConnect(&client, &data);
				if (ret != SUCCESS) {

					ESP_LOGE(TAG, "MQTTConnect: %d", ret);
					if(connect_call)
					{
						if(ret>(CLIENT_ID_NULL-1))
						connect_call(yalgaar_error_string[ret-CLIENT_ID_NULL+1]);
					}
				}
				ESP_LOGI(TAG, "MQTTConnect : ret %d",ret);

				 if(!ret)
				 {
					is_mqtt_connect = 1;
					if(connect_call)
					{
						connect_call(yalgaar_error_string[0]);
					}
					while (1)
					{
						MQTTYield(&client, CLIENT_CONNECTION_TIMEOUT_ms);
						if (!MQTTIsConnected(&client))
						{
							is_mqtt_connect = 0;
							ESP_LOGE(TAG,"Disconnected.......");
							break;
						}
					}
				 }
				 else
				 {
					ESP_LOGE(TAG,"failed to connect mqtt");
				 }
				if(connect_flag)
				{
					connect_flag = false;
					break;
				}

				MQTTDisconnect(&client);
				disconnect_network(&network);
			}
			else
			{
				ESP_LOGE(TAG,"failed to connect to mqtt server");
				disconnect_network(&network);
			}
	vTaskDelay(RECONNECT_TIMEOUT_TICKS);
	}
	if(sendBuf != NULL)
	{
		free(sendBuf);
		sendBuf = NULL;
	}

	if(readBuf != NULL)
	{
		free(readBuf);
		readBuf = NULL;
	}
	vTaskDelete(NULL);
}

bool start_yalgaar_client()
{
	if(yalgaar_task_handle == NULL)
	{
		if(xTaskCreate(mqtt_yalgaar_task, "mqtt_yalgaar_task", YALGAAR_TASK_STACK, NULL, YALGAAR_TASK_PRIO, yalgaar_task_handle) != pdPASS)
		{
			ESP_LOGE(TAG,"mqtt_yalgaar_task : create : fail");
			return false;
		}
	}
	return true;
}


int yalgaar_connect(char* clientKey,char* uuid, void(*connection_callback)(char*), bool isHexString)
{
	if ((clientKey == NULL))
	{
		ESP_LOGE(TAG,"Client key id NULL");
		return ESP_FAIL;
	}
	cli_id = (char*)malloc(CLIENT_ID_SIZE);
	if(cli_id == NULL)
	{
		ESP_LOGE(TAG,"Memory allocation fails.");
		return ESP_FAIL;
	}
	memset(cli_id,0,CLIENT_ID_SIZE);

	global_client_key = (char*)malloc(strlen(clientKey)+1);
	if(global_client_key == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for global client Key");
		free(cli_id);
		return ESP_FAIL;
	}
	memset(global_client_key,0,strlen(clientKey)+1);

	global_uuid = (char*)malloc(strlen(uuid)+1);
	if(global_uuid == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for UUID");
		free(cli_id);
		free(global_client_key);
		return ESP_FAIL;
	}
	memset(global_uuid,0,strlen(uuid)+1);
	if(mqtt_client_connect_ops(clientKey,uuid,cli_id,global_client_key,global_uuid)==ESP_FAIL)
	{
		free(cli_id);
		free(global_client_key);
		free(global_uuid);
		return ESP_FAIL;
	}

	if(!start_yalgaar_client())
	{
		free(cli_id);
		free(global_client_key);
		free(global_uuid);
		return ESP_FAIL;
	}
	connect_call = connection_callback;
	regist_yalgaar_error_callback(connect_call,yalgaar_error_string);
	return 0;
}

int yalgaar_subscribe(char *channel,void (*sub_msg_callback)(char*,int,char*),void (*presence_msg_call)(presence_t*))
{
	if((sub_channel_cnt > MAX_CHANNELS-1))
	{
		ESP_LOGE(TAG,"Maximum subscribe channel limit reached");
		return ESP_FAIL;
	}
	if(channel == NULL)
	{
		ESP_LOGE(TAG,"Channel is NULL");
		return ESP_FAIL;
	}
	char *topic = (char*) malloc((strlen(global_client_key)+strlen(channel)+2));
	if(topic == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for subscribe topic");
		return ESP_FAIL;
	}
	memset(topic,0,(strlen(global_client_key)+strlen(channel)+2));
	append_key(global_client_key,channel,topic);

	/* if yalgaar_subscribe is not called from yalgaar_GetChannelList, yalgaar_GetHistoryMessage, yalgaar_GetUserList 	*/
	if((sub_msg_call == NULL) && (sub_msg_callback != NULL))
	{
		sub_msg_call = sub_msg_callback;
		sub_channel_cnt++;
	}
	if(presence_call == NULL)
	{
		presence_call = presence_msg_call;
	}
	int ret;
	ESP_LOGD(TAG," topic : %s",topic);
	if((ret = MQTTSubscribe(&client,topic,QOS0,messageHandler_func_yalgaar))!=0)
	{
		ESP_LOGE(TAG,"Subscribe fail topic : %s, ret = %d",topic,ret);
		free(topic);
		return ESP_FAIL;
	}
	free(topic);
	return ESP_OK;
}

int yalgaar_subscribes(char **channels,uint8_t channels_numbers,void (*sub_msg_callback)(char*,int,char*),void (*presence_msg_call)(presence_t*))
{
	for(int i=0;i<channels_numbers;i++)
	{
		yalgaar_subscribe(channels[i],sub_msg_callback,presence_msg_call);
	}
	return ESP_OK;
}

int yalgaar_publish(char *channel,char *data, int len)
{
	if(channel == NULL)
	{
		ESP_LOGE(TAG,"Channel is NULL");
		return ESP_FAIL;
	}
	char *topic = (char*) malloc((strlen(global_client_key)+strlen(channel)+2)); /* 2 for '/' and '\0'	*/
	if(topic == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for publish topic");
		return ESP_FAIL;
	}
	memset(topic,0,strlen(global_client_key)+strlen(channel)+2);
	append_key(global_client_key,channel,topic);

	if(global_hex_flag)
	{
		char * sdata = (char*)malloc(2*len);
		if(sdata == NULL)
		{
			ESP_LOGE(TAG,"Memory not allocated for publish hex-data");
			free(topic);
			return ESP_FAIL;
		}
		memset(sdata,0,2*len);
		for(int i=0,j=0;j<len;i+=2,j++)
		{
			sdata[i+1] = (data[j] & 0x0f);
			if(sdata[i+1] > 9)
			{
				sdata[i+1] = sdata[i+1] - 0xa;
				sdata[i+1] = sdata[i+1] + 'A';
			}
			else
				sdata[i+1] = sdata[i+1] + '0';
				ESP_LOGD(TAG,"byte : %c",sdata[i+1]);
			sdata[i] = ((data[j] & 0xf0)>> 4);
			if(sdata[i] > 9)
			{
				sdata[i] = sdata[i] - 0xa;
				sdata[i] = sdata[i] + 'A';
			}
			else
				sdata[i] = sdata[i] + '0';
				ESP_LOGD(TAG,"byte : %c",sdata[i]);
		}
		ESP_LOGD(TAG,"Publish : %s",sdata);
		MQTTMessage message;
		message.payload = sdata;
		message.payloadlen = len*2;
		message.qos = QOS0;
		message.retained = 0;

		if(MQTTPublish(&client, topic, &message)!= 0)
		{
			ESP_LOGE(TAG,"Publish message failed");
			free(topic);
			free(sdata);
			return ESP_FAIL;
		}
		free(topic);
		free(sdata);
		return ESP_OK;
	}
	MQTTMessage message;
	message.payload = data;
	message.payloadlen = len;
	message.qos = QOS0;
	message.retained = 0;
	int ret;
	if((ret=MQTTPublish(&client, topic, &message))!= 0)
	{
		ESP_LOGE(TAG,"Publish message failed,  ret = %d",ret);
		free(topic);
		return ESP_FAIL;
	}
	free(topic);
	return ESP_OK;
}


int yalgaar_GetHistoryMessage(char *channelName,int messageCount, void(*history_msg_callback)(char *history[],int number))
{

	if(channelName == NULL)
	{
		ESP_LOGE(TAG,"Channel is NULL");
		return ESP_FAIL;
	}

	uint8_t len=strlen(global_uuid)+strlen(channelName);
	char msg_count_string[5];
	int cnt=0;
	itoa(messageCount,msg_count_string,10);
	while(msg_count_string[cnt] != '\0')
	{
		cnt++;
	}
	char * append=(char*)malloc(len+11+cnt);	/*	11 for '$'+"$history"+'/'	*/
	if(append == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for history channel");
		return ESP_FAIL;
	}
	memset(append,0,len+11+cnt);
	append_key(global_uuid,channelName,append);
	append[len+1] = '$';
	memcpy(&append[len+2],msg_count_string,cnt);
	memcpy(&append[len+2+cnt],"$history",8);
	append[len+10+cnt]='\0';
	if(yalgaar_subscribe(append,NULL,NULL)!=ESP_OK)
	{
		free(append);
		return ESP_FAIL;
	}

	history_call = history_msg_callback;
	free(append);
	return ESP_OK;
}

int yalgaar_GetUserList(char *channelName,void (*userlist_callback)(sll*))
{
	if(channelName == NULL)
	{
		ESP_LOGE(TAG,"Channel is NULL");
		return ESP_FAIL;
	}
	uint8_t len=strlen(global_uuid)+strlen(channelName);
	char * append=(char*)malloc(len+11);	/* 11 for $10$users	*/
	if(append == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for User list channel");
		return ESP_FAIL;
	}
	memset(append,0,len+11);
	append_key(global_uuid,channelName,append);
	memcpy(&append[len+1],"$10$users",9);
	append[len+10]='\0';
	if(yalgaar_subscribe(append,NULL,NULL)!=ESP_OK)
	{
		free(append);
		return ESP_FAIL;
	}
	user_list_call = userlist_callback;
	free(append);
	return ESP_OK;
}

int yalgaar_GetChannelList(char *uuid,void(*channel_list_callback)(sll*))
{
	if(uuid == NULL)
	{
		ESP_LOGE(TAG,"uuid is NULL");
		return ESP_FAIL;
	}

	uint8_t len=strlen(global_uuid)+strlen(uuid);
	char * append=(char*)malloc(len+14);	/*14  for $10$channels+'/'	*/
	if(append == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for chennal list");
		return ESP_FAIL;
	}
	memset(append,0,len+14);
	append_key(global_uuid,uuid,append);
	memcpy(&append[len+1],"$10$channels",12);
	append[len+13]='\0';
	if(yalgaar_subscribe(append,NULL,NULL)!=ESP_OK)
	{
		free(append);
		return ESP_FAIL;
	}
	channel_list_call = channel_list_callback;
	free(append);
	return ESP_OK;
}
int yalgaar_unsubscribe(char *channel)
{
	if(channel == NULL)
	{
		ESP_LOGE(TAG,"Channel is NULL");
		return ESP_FAIL;
	}
	char *topic = (char*) malloc((strlen(global_client_key)+strlen(channel)+2));
	if(topic == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for un-subscribe topic");
		return ESP_FAIL;
	}
	memset(topic,0,strlen(global_client_key)+strlen(channel)+2);
	append_key(global_client_key,channel,topic);
	if(MQTTUnsubscribe(&client, topic) < 0)
	{
		free(topic);
		return ESP_FAIL;
	}
	free(topic);
	return ESP_OK;
}
void yalgaar_disconnect()
{
	if(global_client_key != NULL)
	{
		free(global_client_key);
		global_client_key=NULL;
	}
	if(global_uuid != NULL)
	{
		free(global_uuid);
		global_uuid=NULL;
	}
	if (MQTTIsConnected(&client))
	{
		connect_flag = true;
		MQTTDisconnect(&client);
		disconnect_network(&network);
		if(sendBuf != NULL)
		{
			free(sendBuf);
			sendBuf = NULL;
		}
		if(readBuf != NULL)
		{
			free(readBuf);
			readBuf = NULL;
		}
		if(cli_id != NULL)
		{
			free(cli_id);
			cli_id = NULL;
		}
		yalgaar_task_handle = NULL;
		vTaskDelete(yalgaar_task_handle);
	}
}
