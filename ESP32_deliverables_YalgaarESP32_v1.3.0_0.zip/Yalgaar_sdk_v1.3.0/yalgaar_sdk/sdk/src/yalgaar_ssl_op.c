#include "MQTTLinux.h"
#include "sdkconfig.h"
#include "mqtt_common.h"
#if CONFIG_SECURE_YALGAAR
#include "mbedtls/platform.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/debug.h"
#include "mbedtls/entropy.h"
#include "mbedtls/error.h"
#include "mbedtls/net.h"
#include "mbedtls/ssl.h"
#endif
#include "yalgaar_api.h"
#include "esp_log.h"

#define SSL_HANDSHAKE_RETRY	10
#define TAG "yalgaar_ssl_ops"

#if CONFIG_SECURE_YALGAAR
#define CRT_INFO_BUFFER_SIZE 1024

typedef struct mqtt_ssl_context_t {
	mbedtls_net_context      server_fd;
	mbedtls_entropy_context  entropy;
	mbedtls_ctr_drbg_context ctr_drbg;
	mbedtls_ssl_context      ssl;
	mbedtls_ssl_config       conf;
	mbedtls_x509_crt         cacert;
} mqtt_ssl_context_t;

static int linux_write_ssl(Network* n, unsigned char* buffer, int len, int timeout_ms);
static int linux_read_ssl(Network* n, unsigned char* buffer, int len, int timeout_ms);
#endif
void Init_network(Network* n)
{
#if CONFIG_SECURE_YALGAAR
	if(n->sslData == NULL)
		n->sslData = (void *)malloc(sizeof(mqtt_ssl_context_t));
	n->mqttread = linux_read_ssl;
	n->mqttwrite = linux_write_ssl;
#else
	NetworkInit(n);
#endif
}

#if CONFIG_SECURE_YALGAAR
static int linux_write_ssl(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	ESP_LOGD(TAG, "linux_write_ssl: %d", len);
	mqtt_ssl_context_t *mqtt_ssl_context = (mqtt_ssl_context_t *)n->sslData;

	struct timeval interval = {timeout_ms / 1000, (timeout_ms % 1000) * 1000};
	if (interval.tv_sec < 0 || (interval.tv_sec == 0 && interval.tv_usec <= 0))
	{
		interval.tv_sec = 0;
		interval.tv_usec = 100;
	}
	setsockopt(mqtt_ssl_context->server_fd.fd, SOL_SOCKET, SO_SNDTIMEO, (char *)&interval,sizeof(struct timeval));

	int ret = mbedtls_ssl_write(&(mqtt_ssl_context->ssl), buffer, len);
	if (ret < 0) {
	ESP_LOGE(TAG, "error from write: %d \n", ret);
	}
	return ret;
}

int linux_read_ssl(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	int bytes = 0;
	mqtt_ssl_context_t *mqtt_ssl_context = (mqtt_ssl_context_t *)n->sslData;
	struct timeval interval = {timeout_ms / 1000, (timeout_ms % 1000) * 1000};
	if (interval.tv_sec < 0 || (interval.tv_sec == 0 && interval.tv_usec <= 0))
	{
		interval.tv_sec = 0;
		interval.tv_usec = 100;
	}

	setsockopt(mqtt_ssl_context->server_fd.fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&interval, sizeof(struct timeval));

	while (bytes < len)
	{
		int rc = mbedtls_ssl_read(&(mqtt_ssl_context->ssl), &buffer[bytes], (size_t)(len - bytes));
		if(rc > 0)
		{
			bytes += rc;
		}
		else
		{
			break;
		}
	}
	return bytes;
}


static void my_debug(void *ctx, int level, const char *file, int line, const char *str) {
   ((void) level);
   ((void) ctx);
   ESP_LOGI(TAG,"%s:%04d: %s", file, line, str);
}

static int my_verify( void *data, mbedtls_x509_crt *crt, int depth, uint32_t *flags )
{
    char buf[CRT_INFO_BUFFER_SIZE];
    ((void) data);
    mbedtls_x509_crt_info( buf, sizeof( buf ) - 1, " ", crt );

    if ( ( *flags ) == 0 )
	{
     ESP_LOGD(TAG, "This certificate has no flags\n\r" );
     ESP_LOGD(TAG,"%s\n\r", buf );
	}
    else
    {
		memset(buf,0,CRT_INFO_BUFFER_SIZE);
        mbedtls_x509_crt_verify_info( buf, sizeof( buf ), "  ! ", *flags );
		ESP_LOGD(TAG,"%s\n\r", buf );
    }
    return( 0 );
}

int NetworkConnectSSL(Network *n, char *addr, int port) {

	uint8_t retry = 0;
	char *pers = "ssl_client1";
	char portStr[8];
    extern const unsigned char cacert_pem_start[] asm("_binary_yalgaar_io_pem_start");
    extern const unsigned char cacert_pem_end[]   asm("_binary_yalgaar_io_pem_end");
    const unsigned int cacert_pem_bytes = cacert_pem_end - cacert_pem_start;
	ESP_LOGI(TAG,"Going for secure connection...");
	ESP_LOGD(TAG,"cacert_pem_bytes = %d",cacert_pem_bytes);
	mqtt_ssl_context_t *mqtt_ssl_context = (mqtt_ssl_context_t *)n->sslData;
	mbedtls_net_init(&mqtt_ssl_context->server_fd);
	mbedtls_ssl_init(&mqtt_ssl_context->ssl);
	mbedtls_ssl_config_init(&mqtt_ssl_context->conf);
	mbedtls_x509_crt_init(&mqtt_ssl_context->cacert);
	mbedtls_ctr_drbg_init(&mqtt_ssl_context->ctr_drbg);
	mbedtls_entropy_init(&mqtt_ssl_context->entropy);

	int ret = mbedtls_ctr_drbg_seed(
	&mqtt_ssl_context->ctr_drbg,
	mbedtls_entropy_func, &mqtt_ssl_context->entropy, (const unsigned char *) pers, strlen(pers));
	if (ret != 0) {
		ESP_LOGE(TAG, " failed  ! mbedtls_ctr_drbg_seed returned %x\n", ret);
		return ret;
	}

	ret = mbedtls_x509_crt_parse( &mqtt_ssl_context->cacert, (const unsigned char *) cacert_pem_start, cacert_pem_bytes );
	if (ret != 0) {
		ESP_LOGE(TAG, " failed  ! mbedtls_x509_crt_parse returned %x\n\n", ret);
		return ret;
	}

	sprintf(portStr, "%d", port);
	ESP_LOGD(TAG, "calling mbedtls_net_connect: %s %s", addr, portStr);
	ret = mbedtls_net_connect(&mqtt_ssl_context->server_fd, addr, portStr, MBEDTLS_NET_PROTO_TCP);
	if (ret != 0) {
		ESP_LOGE(TAG, " failed  ! mbedtls_net_connect returned %x\n\n", ret);
		return ret;
	}

	ret = mbedtls_ssl_config_defaults(
	&mqtt_ssl_context->conf,
	MBEDTLS_SSL_IS_CLIENT,
	MBEDTLS_SSL_TRANSPORT_STREAM,
	MBEDTLS_SSL_PRESET_DEFAULT);
	if (ret != 0) {
		ESP_LOGE(TAG, " failed  ! mbedtls_ssl_config_defaults returned %x\n\n", ret);
		return ret;
	}

	mbedtls_ssl_conf_verify( &mqtt_ssl_context->conf, my_verify, NULL );
	ESP_LOGD(TAG,"mbedtls_ssl_conf_verify done");

	mbedtls_ssl_conf_authmode(&mqtt_ssl_context->conf, MBEDTLS_SSL_VERIFY_REQUIRED );
	ESP_LOGD(TAG,"mbedtls_ssl_conf_authmode done");

	mbedtls_ssl_conf_ca_chain( &mqtt_ssl_context->conf, &mqtt_ssl_context->cacert, NULL );
	ESP_LOGD(TAG,"mbedtls_ssl_conf_ca_chain done");

	mbedtls_ssl_conf_rng(&mqtt_ssl_context->conf, mbedtls_ctr_drbg_random, &mqtt_ssl_context->ctr_drbg);
	ESP_LOGD(TAG,"mbedtls_ssl_conf_rng done");

	mbedtls_ssl_conf_dbg(&mqtt_ssl_context->conf, my_debug, stdout);
	ret = mbedtls_ssl_setup(&mqtt_ssl_context->ssl, &mqtt_ssl_context->conf);
	if (ret != 0) {
		ESP_LOGE(TAG, "error from mbedtls_ssl_setup: %d \n", ret);
		return ret;
	}

	ret = mbedtls_ssl_set_hostname(&mqtt_ssl_context->ssl, YALGAAR_SERVER);
	if (ret != 0) {
		ESP_LOGE(TAG, "error from mbedtls_ssl_set_hostname: %d\n", ret);
		return ret;
	}

	mbedtls_ssl_set_bio(&mqtt_ssl_context->ssl, &mqtt_ssl_context->server_fd, mbedtls_net_send, mbedtls_net_recv, NULL);
	ESP_LOGD(TAG,"mbedtls_ssl_set_bio done");

	ESP_LOGI(TAG,"Starting SSL Handshake......");
    while( ( ret = mbedtls_ssl_handshake( &mqtt_ssl_context->ssl ) ) != 0 )
    {
        if( ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE )
        {
            ESP_LOGE(TAG, " failed  ! mbedtls_ssl_handshake returned -0x%x\n\n", ret );
        }
		if(retry++ > SSL_HANDSHAKE_RETRY)
			break;
		vTaskDelay(1);
	}

	if(retry >= SSL_HANDSHAKE_RETRY)
		return -1;

	return 0;
}
#endif

int connect_network(Network* n, char* host)
{
#if CONFIG_SECURE_YALGAAR
	return (NetworkConnectSSL(n,host,YALGAAR_SECURE_PORT));
#else
	return(NetworkConnect(n,host,YALGAAR_NON_SECURE_PORT));
#endif
}

void disconnect_network(Network* n)
{
#if CONFIG_SECURE_YALGAAR
	ESP_LOGI(TAG,"Deleting network.....");
	mqtt_ssl_context_t *mqtt_ssl_context = (mqtt_ssl_context_t *)n->sslData;
	mbedtls_net_free(&mqtt_ssl_context->server_fd);
	mbedtls_ssl_free(&mqtt_ssl_context->ssl);
	mbedtls_ssl_config_free(&mqtt_ssl_context->conf);
	mbedtls_ctr_drbg_free(&mqtt_ssl_context->ctr_drbg);
	mbedtls_entropy_free(&mqtt_ssl_context->entropy);
	mbedtls_x509_crt_free( &mqtt_ssl_context->cacert);
	if (n->sslData != NULL)
	{
		free(n->sslData);
		n->sslData = NULL;
	}
#else
	NetworkDisconnect(n);
#endif
}
