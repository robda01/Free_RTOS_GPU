#include <stdint.h>
#include <stdlib.h>
#include "esp_log.h"
#include "yalgaar_api.h"

#define TAG "mqtt_common.c"

#define UUID_SIZE	10
static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
uint8_t is_mqtt_connect;
static uint8_t flag_uuid;

uint8_t is_mqtt_connected()
{
	return is_mqtt_connect;
}

void append_key(char* clientKey, char* uuid, char* client)
{
	int l=strlen(clientKey);
	int m=strlen(uuid);
	memcpy(client,clientKey,l);
	client[l]='/';
	memcpy(&client[l+1],uuid,m);
	client[l+m+1]='\0';
}

int mqtt_client_connect_ops(char* clientKey,char* uuid,char* cli_id,char* global_client_key,char* global_uuid)
{
	if ((clientKey == NULL))
	{
		ESP_LOGE(TAG,"Client key id NULL");
		return ESP_FAIL;
	}
	if(uuid == NULL)
	{
		ESP_LOGE(TAG,"uuid is NULL");
		ESP_LOGI(TAG,"Generating random uuid");
		uuid = (char*)malloc(UUID_SIZE);
		if(uuid == NULL)
		{
			ESP_LOGE(TAG,"random uuid buffer alloc failed");
			return ESP_FAIL;
		}
		memset(uuid,0,UUID_SIZE);
		flag_uuid = 1;
		for (int i = 0; i < UUID_SIZE-1; ++i) {
		uuid[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
		}
		uuid[UUID_SIZE-1]=0;
	}
	ESP_LOGD(TAG,"uuid %s",uuid);

	memcpy(global_client_key,clientKey,strlen(clientKey)+1);
	memcpy(global_uuid,uuid,strlen(uuid)+1);

	char *client_ID = (char*)malloc((strlen(clientKey)+strlen(uuid))+2);
	if(client_ID == NULL)
	{
		ESP_LOGE(TAG,"Memory not allocated for Client ID");
		if(flag_uuid)
		{
			free(uuid);
			flag_uuid = 0;
		}
		return ESP_FAIL;
	}
	memset(client_ID,0,(strlen(clientKey)+strlen(uuid))+2);
	append_key(clientKey,uuid,client_ID);
	ESP_LOGD(TAG,"CLient  ====== %s",client_ID);
	memcpy(cli_id,client_ID,(strlen(clientKey)+strlen(uuid))+2);
	if(flag_uuid)
	{
		free(uuid);
		flag_uuid = 0;
	}
	free(client_ID);
	return ESP_OK;
}


