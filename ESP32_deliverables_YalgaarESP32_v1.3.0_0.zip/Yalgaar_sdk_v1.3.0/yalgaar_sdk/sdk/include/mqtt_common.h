#if !defined(__MQTT_COMMON_H_)
#define __MQTT_COMMON_H_

#include <stdint.h>
#include <stdbool.h>
#include "esp_system.h"

#define RECONNECT_TIMEOUT_TICKS			2000
#define CLIENT_CONNECTION_TIMEOUT_ms	1000
#define Ms_To_Us_MUL					1000
#define MQTT_BUFFER_SIZE 				2*1024
#define CLIENT_ID_SIZE					50

#define YALGAAR_TASK_PRIO	CONFIG_YALGAAR_TASK_PRIO
#define YALGAAR_TASK_STACK	CONFIG_YALGAAR_TASK_SIZE

/**
 * @brief  MQTT client is connected or not.
 *
 * @param  None.
 *
 * @return
 *    - 1: connected
 *    - 0: not connected
 */
uint8_t is_mqtt_connected();


#endif
