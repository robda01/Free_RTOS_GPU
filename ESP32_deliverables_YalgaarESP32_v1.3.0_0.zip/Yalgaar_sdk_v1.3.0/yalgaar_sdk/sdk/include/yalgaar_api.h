#ifndef _YALGAAR_H_
#define _YALGAAR_H_

#include "MQTTClient.h"
#include "sdkconfig.h"
#include "esp_system.h"

#define YALGAAR_SERVER "api.yalgaar.io"
#define YALGAAR_NON_SECURE_PORT	1883
#define YALGAAR_SECURE_PORT	8883

/*		Return code as per Yalgaar server	*/
typedef enum yalgaar_error_t
{
	CONNECTION_SUCCESS		=	0,

	CLIENT_ID_NULL 			=	101,
	INVALID_CLIENT_ID		=	102,
	INVALID_CLIENT_KEY		=	103,
	INVALID_UUID			=	104,
	CLIENT_KEY_NOT_ACTIVE	=	105,
	SSL_NOT_ENABLE			=	106,
	MAX_CONNECTION			=	107,
	INVALID_SUB_CH			=	108,
	INVALID_SUB_CH_KEY		=	109,
	MULTIPLE_CHANNELS		=	110,
	INVALID_SUB_CH_STRING	=	111,
	HISTORY_STORAGE_DIS		=	112,
	PRESENCE_DISABLE		=	113,
	WRONG_HISTORY_CHANNEL	=	114,
	PUB_MSG_NULL			=	115,
	INVALID_PUB_CH			=	116,
	INVALID_PUB_CH_KEY		=	117,
	MAX_MSG_COUNT			=	118,
	MAX_MSG_SIZE			=	119,
	INVALID_PUB_CH_STRING	=	120,
	INVALID_UNSUB_CH		=	121,
	INVALID_UNSUB_CH_KEY	=	122,
	INVALID_UNSBU_CH_STRING	=	123,
	UNAUTHORIZED_DOMAIN		=	124,
	UUID_SUBSCRIBE_DISABLED =   125,
	UUID_PUBLISH_DISABLED	=	126
}yalgaar_error_t;


/**
 * @brief Presence information structure
 */
typedef struct presence_t
{
	char uuid[50];
	bool action;
	char channel[50];
}presence_t;

/**
 * @brief Channel list and users list data structure
 */
typedef struct sll
{
	char **list;
	uint8_t low_range;
	uint8_t high_range;
}sll;

/**
 * @brief Connect Client to yalgaar
 *
 * @param clientKey Client Key
 *		  uuid uuid of client
 *		  connection_callback callback function which will be called after connection successful, Also server error code will be provided in this  *		callback function
 *		  isHexString if true, data will be considered in Hex and converted to string, else considered as string.
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */

int yalgaar_connect(char* clientKey,char* uuid, void(*connection_callback)(char*), bool isHexString);

/**
 * @brief Publish on channel
 *
 * @param channel channel name
 *		  data reference to data to be published
 *		  len length of data to be published
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_publish(char *channel,char *data, int len);


/**
 * @brief Subscribe on channel
 *
 * @param channel channel name
 *		  sub_msg_callback callback function in which data will be provided of subscribed channel
 *		  presence_msg_call Presence channels details will be provided in this callback function
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_subscribe(char *channel,void (*sub_msg_callback)(char*,int,char*),void (*presence_msg_call)(presence_t*));

/**
 * @brief Subscribe on multiple channels
 *
 * @param channels channel list
 *		  sub_msg_callback callback function in which data will be provided of subscribed channel
 *		  presence_msg_call Presence channels details will be provided in this callback function
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_subscribes(char **channels,uint8_t channels_numbers,void (*sub_msg_callback)(char*,int,char*),void (*presence_msg_call)(presence_t*));

/**
 * @brief Unsubscribe on channel
 *
 * @param channel channel name
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_unsubscribe(char *channel);

/**
 * @brief Disconnect Yalgaar
 *
 * @param None
 *
 * @return None
 *
 */
void yalgaar_disconnect();

/**
 * @brief Get History messages of given channel
 *
 * @param channelName channel name
 *		  messageCount Numbers of messages to get
 *		  history_msg_callback callback function in which messages will be provided
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_GetHistoryMessage(char *channelName,int messageCount, void(*history_msg_callback)(char** data,int count));

/**
 * @brief Get Channels list subscribed by given uuid
 *
 * @param uuid user uuid
 *		  channel_list_callback callback function in which channel list will be provided in sll structure
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_GetChannelList(char *uuid,void(*channel_list_callback)(sll*));

/**
 * @brief Get user list subscribed on given channel
 *
 * @param channelName channel name
 *		  userlist_callback callback function in which user list will be provided in sll structure
 *
 * @return
 *     - ESP_FAIL if fail
 *     - ESP_OK if succeed
 */
int yalgaar_GetUserList(char *channelName,void (*userlist_callback)(sll*));

#endif
