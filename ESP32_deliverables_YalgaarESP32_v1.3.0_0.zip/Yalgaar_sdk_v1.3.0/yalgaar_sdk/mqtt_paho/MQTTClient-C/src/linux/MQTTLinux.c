/*******************************************************************************
 * Copyright (c) 2014, 2017 IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * and Eclipse Distribution License v1.0 which accompany this distribution.
 *
 * The Eclipse Public License is available at
 *    http://www.eclipse.org/legal/epl-v10.html
 * and the Eclipse Distribution License is available at
 *   http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * Contributors:
 *    Allan Stockdill-Mander - initial API and implementation and/or initial documentation
 *    Ian Craggs - return codes from linux_read
 *******************************************************************************/

#include "MQTTLinux.h"

void TimerInit(Timer* timer)
{
	timer->xTicksToWait = 0;
	memset(&timer->xTimeOut, '\0', sizeof(timer->xTimeOut));
}

char TimerIsExpired(Timer* timer)
{
	return xTaskCheckForTimeOut(&timer->xTimeOut, &timer->xTicksToWait) == pdTRUE;
}


void TimerCountdownMS(Timer* timer, unsigned int timeout)
{
	timer->xTicksToWait = timeout / portTICK_PERIOD_MS; /* convert milliseconds to ticks */
	vTaskSetTimeOutState(&timer->xTimeOut); /* Record the time at which this function was entered. */
}


void TimerCountdown(Timer* timer, unsigned int timeout)
{
	TimerCountdownMS(timer, timeout * 1000);
}


int TimerLeftMS(Timer* timer)
{
	xTaskCheckForTimeOut(&timer->xTimeOut, &timer->xTicksToWait); /* updates xTicksToWait to the number left */
	return (timer->xTicksToWait < 0) ? 0 : (timer->xTicksToWait * portTICK_PERIOD_MS);
}


int linux_read(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	struct timeval interval = {timeout_ms / 1000, (timeout_ms % 1000) * 1000};
	if (interval.tv_sec < 0 || (interval.tv_sec == 0 && interval.tv_usec <= 0))
	{
		interval.tv_sec = 0;
		interval.tv_usec = 100;
	}
	int bytes = 0;
	fd_set fdset;
	int rc = 0;

	FD_ZERO(&fdset);
	FD_SET(n->my_socket, &fdset);

	rc = select(n->my_socket + 1, &fdset, 0, 0, &interval);
	if ((rc > 0) && (FD_ISSET(n->my_socket, &fdset)))
	{
		while (bytes < len)
		{
			int rc = recv(n->my_socket, &buffer[bytes], (size_t)(len - bytes), 0);
			if (rc == -1)
			{
				if (errno != EAGAIN && errno != EWOULDBLOCK)
				  bytes = -1;
				break;
			}
			else if (rc == 0)
			{
				bytes = 0;
				break;
			}
			else
				bytes += rc;
		}
	}
	return bytes;
}


int linux_write(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	struct timeval tv;

	tv.tv_sec = 0;  /* 30 Secs Timeout */
	tv.tv_usec = timeout_ms * 1000;  // Not init'ing this can cause strange errors

	setsockopt(n->my_socket, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv,sizeof(struct timeval));
	int	rc = write(n->my_socket, buffer, len);
	return rc;
}


void NetworkInit(Network* n)
{
	n->my_socket = 0;
	n->mqttread = linux_read;
	n->mqttwrite = linux_write;
}

int host2addr(const char *hostname , struct in_addr *in)
{
	struct addrinfo hints, *servinfo, *p;
	struct sockaddr_in *h;
	int rv;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	rv = getaddrinfo(hostname, 0 , &hints , &servinfo);
	if (rv != 0)
	{
		return rv;
	}

	// loop through all the results and get the first resolve
	for (p = servinfo; p != 0; p = p->ai_next)
	{
		h = (struct sockaddr_in *)p->ai_addr;
		in->s_addr = h->sin_addr.s_addr;
	}
	freeaddrinfo(servinfo); // all done with this structure
	return 0;
}

/*	modified SLS	*/
int NetworkConnect(Network* n, char* host, int port)
{
	struct sockaddr_in addr;
	int ret;

	if (host2addr(host, &(addr.sin_addr)) != 0)
	{
		return -1;
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);

	n->my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if( n->my_socket < 0 )
	{
		// error
		return -1;
	}

	ret = connect(n->my_socket, ( struct sockaddr *)&addr, sizeof(struct sockaddr_in));
	if( ret < 0 )
	{
		// error
		close(n->my_socket);
		return ret;
	}

	return ret;
}


void NetworkDisconnect(Network* n)
{
	close(n->my_socket);
	n->my_socket = -1;
}
