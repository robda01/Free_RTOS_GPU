#include "yalgaar_api.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_system.h"

#define TAG "Yalgaar_sdk"

int connected_flag=0;

void sub_msg_fun (char *data,int len, char *channel);
void presence_fun(presence_t * data)
{
	ESP_LOGI(TAG,"Presence uuid : %s",data->uuid);
	ESP_LOGI(TAG,"Presence channel : %s",data->channel);
	ESP_LOGI(TAG,"Presence action : %d",data->action);
	ESP_LOGI(TAG,"heap: %d",esp_get_free_heap_size());
}

void connect_done(char* arg)
{
	char test_data[]="This is ESP32 Yalgaar SDK Example";
	if(strcmp(arg,"Connection Successful") == 0)
	{
		connected_flag = 1;
		ESP_LOGI("connection successful","arg : %s",arg);
		if(yalgaar_subscribe("yourchannel", sub_msg_fun, presence_fun)== ESP_FAIL)
		{
			ESP_LOGE(TAG,"channel not subscribed");
		}
		if(yalgaar_publish("yourchannel",test_data,strlen(test_data))== ESP_FAIL)
		{
			ESP_LOGE(TAG,"Yalgaar Publish fail");
		}
		return;
	}
	ESP_LOGE(TAG,"Yalgaar ERROR : %s",arg);
 }

void sub_msg_fun (char *data,int len, char* channel)
{
	ESP_LOGI(TAG,"Data Received from channel : %s",channel);
	ESP_LOGI(TAG,"Data : %s",(char*)data);
}

void yalgaar_demo_task(void *p)
{
	/*	connect yalgaar client	*/
	int c = yalgaar_connect("yourclientkey","uuid",connect_done,0);
	if(c == ESP_FAIL)
	{
		ESP_LOGE(TAG,"Yalgaar Connection failed");
	}
	vTaskDelete(NULL);
}